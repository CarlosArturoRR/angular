import { EvaluacionPage } from './app.po';

describe('evaluacion App', function() {
  let page: EvaluacionPage;

  beforeEach(() => {
    page = new EvaluacionPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
