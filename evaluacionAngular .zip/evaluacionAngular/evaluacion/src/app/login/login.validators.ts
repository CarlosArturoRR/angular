import { AbstractControl, ValidatorFn, Validators } from '@angular/forms';
import { LoginService } from './login.service';

export class LoginValidators {
  static valorUnico(servicio: LoginService): ValidatorFn {
    return (control: AbstractControl): {[key:string]:any} => {
      if (this.isPresent(Validators.required(control))) return null;
      var v= control.value;

      return new Promise((resolve, reject) => {
        servicio.getUsuario(v).subscribe(
          data => {
            if(data.length > 0)
              resolve(null);
            else
              resolve({valorUnico:true});

          },
          err => resolve({valorUnico:true})
        )
      })
    }
  }

  static isPresent (obj: any): boolean {
    return obj !== undefined && obj !== null;
  }
}
