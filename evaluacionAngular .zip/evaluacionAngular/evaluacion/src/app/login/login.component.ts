import { Component, OnInit } from '@angular/core';
import { LoginService } from  './login.service';
import { Login } from './login';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginValidators } from './login.validators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[LoginService]
})
export class LoginComponent implements OnInit {

  lista: Login[];
  form: FormGroup;
  login: Login[];
  constructor(
    private router: Router,
    private servicio: LoginService,
    private fb: FormBuilder
  ) { this.crearControles(); }

  ngOnInit() {
    this.servicio.getUsuarios()
                 .subscribe(
                   rs => this.lista = rs,
                   er => console.log(er),
                   () => console.log(this.lista)
                 )

  }

  crearControles(){
    this.form = this.fb.group({
      email:['', Validators.required, LoginValidators.valorUnico(this.servicio)],
      contrasena:['', Validators.compose([
        Validators.required
      ])]
    })
  }

  entrar(item1, item2){
    this.servicio.getUsuario(item1.value)
                .subscribe(
                  rs => this.login = rs,
                  er => console.log('Error: %s', er),
                  ()=> {
                    if (this.login.length > 0){
                      if (item2.value==this.login[0].contrasena){
                        let link = ['/home/'];
                        this.router.navigate(link);
                      } else {
                        alert('Las credenciales no son validas');
                      }
                    }
                  }
                )


  }

}
