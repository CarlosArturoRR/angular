import { Component, OnInit } from '@angular/core';
import { Home } from './home';
import { Filtrar } from './filtrar';
import { Cantidad } from './cantidad';
import { Carrito } from './carrito';
import { Contador } from './contador';

import { HomeService } from './home.service';
import { CarritoService } from './carrito.service';
import { ContadorService } from './contador.service';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers:[HomeService, CarritoService, ContadorService]
})
export class HomeComponent implements OnInit {


  contador: Contador[];
  lista: Home[];
  form: FormGroup;
  filtrar: Filtrar;
  cantidad: Cantidad;
  carrito: Carrito;




  constructor(
    private servicio: HomeService,
    private servicio1: CarritoService,
    private servicio2: ContadorService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,


  ) { this.crearControles(); }

  ngOnInit() {
    //this.appRoutes.navigateByUrl('/home');
    this.servicio.getProductos()
        .subscribe(
          rs => this.lista = rs,
          er => console.log(er),
          () => console.log(this.lista)
        )

  }

  crearControles(){
    this.form = this.fb.group({
      buscar:''
    })
  }

  filtrarProductos(item1){
    console.log(this.isPresent(item1))
    console.log(item1)
    if (this.isPresent(item1)){
    this.servicio.getFiltro(item1)
                .subscribe(
                  rs => this.lista = rs,
                  er => console.log('Error: %s', er),
                  ()=> {
                    if (this.lista.length > 0){

                        let link = ['/home/'];
                        this.router.navigate(link);

                    }
                  }
                )


  }
}

mostrarDetalle(id){
  let link = ['/detalle',id];
  this.router.navigate(link);
}

 isPresent (obj: any): boolean {
  return obj !== undefined && obj !== null;
}

Carritoadd(item: Home, cantidad){
  if (this.isPresent(cantidad)){
    if (cantidad > 0){
      let pedido = new Carrito('hola','',1,1,1);
      pedido.nombre = item.nombre;
      pedido.imagen = item.imagen;
      pedido.precio = item.precio;
      pedido.cantidad = cantidad;
      pedido.costo = pedido.precio * cantidad;
      console.log(pedido.nombre);
      console.log(cantidad);

      let c = new Contador(0);
      c.contador = 12;
      console.log(c.contador);

      this.servicio1.addInventario(pedido)
            .subscribe(
              rt => console.log(rt),
              er => console.log(er),
              () => console.log('Terminado')
            );
      this.ContarCarrito();
    } else {
      alert ("La cantidad tiene que se mayor a cero")
    }
  } else {
    alert("Es necesario que registr la cantidad")
  }
  }

  ContarCarrito(){
    this.servicio2.contarCarrito()
                .subscribe(
                  rs => this.contador = rs,
                  er => console.log('Error: %s', er),
                  ()=> {
                    if (this.contador.length > 0){



                    }
                  }
                )
  }
}
