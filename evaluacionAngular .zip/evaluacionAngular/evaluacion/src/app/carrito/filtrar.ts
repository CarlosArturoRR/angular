export class Filtrar {
  constructor(
    public filtro: string

  ) { }
}
