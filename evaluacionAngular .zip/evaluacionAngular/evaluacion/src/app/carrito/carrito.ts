export class Carrito {
  constructor(
    public nombre: string,
    public imagen: string,
    public precio: number,
    public cantidad: number,
    public costo: number
  ) { }
}
