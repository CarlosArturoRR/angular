export class Pagado {
  constructor(
    public nombre: string,
    public disponibilidad: number
  ) { }
}
