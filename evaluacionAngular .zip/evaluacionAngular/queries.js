var conexion = require('./connections.js')

function MetodosDB(){
  this.seleccionarProducto = function(respuesta){
    conexion.obtener(function(er, cn){
      cn.query('Select * from producto', function(error, resultado){
        cn.release();
        if (error){
          respuesta.send({ estado: 'Error' })
        } else {
          respuesta.send(resultado);
        }
      })
    })
  }

  this.actualizarProducto = function(datos,respuesta){
  conexion.obtener(function(er,cn){
    cn.query('UPDATE producto SET  ? WHERE nombre = ?', [datos, datos.nombre], function(error, resultado){
      cn.release();
      if (error){
        respuesta.send({ estado: 'Error' } );
      } else {
        respuesta.send({ estado: 'ok' } )
      }
    })
  })
  }

  this.carritoCompleto = function(respuesta){
    conexion.obtener(function(er, cn){
      cn.query('Select * from carrito', function(error, resultado){
        cn.release();
        if (error){
          respuesta.send({ estado: 'Error' })
        } else {
          respuesta.send(resultado);
        }
      })
    })
  }

  this.contarCarrito = function(respuesta){
    conexion.obtener(function(er, cn){
      cn.query('SELECT count(1) contador FROM carrito', function(error, resultado){
        cn.release();
        if (error){
          respuesta.send({ estado: 'Error' })
        } else {
          respuesta.send(resultado);
        }
      })
    })
  }

  this.totalCarrito = function(respuesta){
    conexion.obtener(function(er, cn){
      cn.query('SELECT sum(costo) total FROM carrito', function(error, resultado){
        cn.release();
        if (error){
          respuesta.send({ estado: 'Error' })
        } else {
          respuesta.send(resultado);
        }
      })
    })
  }

  this.borrarCarrito = function(respuesta){
    conexion.obtener(function(er, cn){
      cn.query('delete FROM carrito', function(error, resultado){
        cn.release();
        if (error){
          respuesta.send({ estado: 'Error' })
        } else {
          respuesta.send({ estado: 'ok' });
        }
      })
    })
  }

  this.seleccionarFiltro = function(id, respuesta) {
    conexion.obtener(function(er, cn){
      cn.query('SELECT * FROM producto WHERE nombre like ?', id+'%', function(error, resultado){
        cn.release();
        if (error) {
          respuesta.send({ estado: 'Error'})
        } else {
          respuesta.send(resultado);
        }
      })
    })
  }



  this.seleccionarId = function(id, respuesta) {
    conexion.obtener(function(er, cn){
      cn.query('SELECT * FROM producto WHERE nombre = ?', id, function(error, resultado){
        cn.release();
        if (error) {
          respuesta.send({ estado: 'Error'})
        } else {
          respuesta.send(resultado);
        }
      })
    })
  }

  this.insertarCarrito = function(datos,respuesta){
  conexion.obtener(function(er,cn){
    cn.query('insert into carrito set ?', datos, function(error, resultado){
      cn.release();
      if (error){
        respuesta.send({ estado: 'Error' });
      } else {
        respuesta.send({ estado: 'ok' });
      }
    })
  })
}


  this.seleccionar = function(respuesta){
    conexion.obtener(function(er, cn){
      cn.query('Select * from usuarios', function(error, resultado){
        cn.release();
        if (error){
          respuesta.send({ estado: 'Error' })
        } else {
          respuesta.send(resultado);
        }
      })
    })
  }

  this.seleccionarId = function(id, respuesta) {
    conexion.obtener(function(er, cn){
      cn.query('select * from usuarios where email=?', id, function(error, resultado){
        cn.release();
        if (error) {
          respuesta.send({ estado: 'Error'})
        } else {
          respuesta.send(resultado);
        }
      })
    })
  }

  this.insertar = function(datos, respuesta) {
    conexion.obtener(function(er, cn){
      cn.query('insert into usuarios set ?', datos, function(error, resultado){
        cn.release();
        if (error) {
          respuesta.send({ estado: 'Error'});
        } else {
          respuesta.send({ estado: 'ok'});
        }
      })
    })
  }

  this.actualizar = function(datos,respuesta){
  conexion.obtener(function(er,cn){
    cn.query('update usuarios set ? where email = ?', [datos, datos.email], function(error, resultado){
      cn.release();
      if (error){
        respuesta.send({ estado: 'Error' } );
      } else {
        respuesta.send({ estado: 'ok' } )
      }
    })
  })
  }

  this.borrar = function(id, respuesta){
    conexion.obtener(function(er, cn){
      cn.query('delete from usuarios where email = ?', id, function(error, resultado){
        cn.release();
        if (error){
          respuesta.send({ estado: 'Error'});
        } else {
          respuesta.send({ estado: 'ok'});
        }
      })
    })
  }

}

module.exports = new MetodosDB();
