var db = require('./queries');

function http(){
  this.configurar = function(app){
    app.get('/producto/', function(solicitud, respuesta){
      db.seleccionarProducto(respuesta);
    })

    app.put('/pagado/', function(solicitud, respuesta){
      db.actualizarProducto(solicitud.body, respuesta);
    })

    app.get('/producto/:id/', function(solicitud, respuesta){
      db.seleccionarFiltro(solicitud.params.id, respuesta);
    })

    app.get('/producto1/:id/', function(solicitud, respuesta){
      db.seleccionarId(solicitud.params.id, respuesta);
    })

    app.post('/carrito/', function(solicitud, respuesta){
      db.insertarCarrito(solicitud.body, respuesta);
    })

    app.delete('/borrar/', function(solicitud, respuesta){
      db.borrarCarrito(respuesta);
    })

    app.get('/contar/', function(solicitud, respuesta){
      db.contarCarrito(respuesta);
    })

    app.get('/total/', function(solicitud, respuesta){
      db.totalCarrito(respuesta);
    })

    app.get('/carritocompleto/', function(solicitud, respuesta){
      db.carritoCompleto(respuesta);
    })

    app.get('/usuarios/', function(solicitud, respuesta){
      db.seleccionar(respuesta);
    })

    app.get('/usuarios/:id/', function(solicitud, respuesta){
      db.seleccionarId(solicitud.params.id, respuesta);
    })

    app.post('/usuarios/', function(solicitud, respuesta){
      db.insertar(solicitud.body, respuesta);
    })

    app.put('/usuarios/', function(solicitud, respuesta){
      db.actualizar(solicitud.body, respuesta);
    })

    app.delete('/usuarios/:id/', function(solicitud, respuesta){
      db.borrar(solicitud.params.id, respuesta);
    })
  }
}

module. exports = new http();
