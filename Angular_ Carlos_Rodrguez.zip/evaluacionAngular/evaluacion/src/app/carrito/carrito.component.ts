import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Carrito } from './carrito';
import { TotalCarritoService } from './totalcarrito.service';
import { CarritoService } from './carrito.service';
import { Totalcompra } from './totalcompra';
import { HomeService } from './home.service';
import { PagadoService } from './pagado.service';
import { Home } from './home';
import { Filtrar } from './filtrar';
import { Pagado } from './pagado';
import { BorrarService } from './borrar.service';




@Component({
  selector: 'app-carrito',
  templateUrl: './carrito.component.html',
  styleUrls: ['./carrito.component.css'],
  providers:[CarritoService, TotalCarritoService, HomeService, PagadoService, BorrarService]
})
export class CarritoComponent implements OnInit {

  lista: Carrito [];
  lista2: Home [];
  total: Totalcompra [];
  filtrar: Filtrar;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private servicio: CarritoService,
    private servicio1: TotalCarritoService,
    private servicio2: HomeService,
    private servicio3: PagadoService,
    private servicio4: BorrarService
  ) { }

  ngOnInit() {
    this.servicio.getCarrito()
                 .subscribe(
                   rs => this.lista = rs,
                   er => console.log('Error: %s', er),
                   () => console.log(this.lista)
                 )
    this.servicio1.getTotal()
                  .subscribe(
                      rs => this.total = rs,
                      er => console.log('Error: %s', er),
                      () => console.log(this.total)
                    )
  }

  Regresar(){
    let link = ['/home'];
    this.router.navigate(link);
  }

  Pagar(item: Carrito[]){
    let c = 0;
    c=0;
    for (let elemento of this.lista){


      console.log(elemento.nombre);
      console.log(c);
      this.servicio2.getFiltro(elemento.nombre)
                  .subscribe(
                    rs => this.lista2 = rs,
                    er => console.log('Error: %s', er),
                    ()=> {
                      if (this.lista2.length > 0){

                          console.log(c,this.lista2[0].nombre);
                          console.log(c,this.lista2[0].disponibilidad);

                          let pedido = new Pagado('',1);
                          pedido.nombre = this.lista2[0].nombre;
                          pedido.disponibilidad = this.lista2[0].disponibilidad-elemento.cantidad;



                          this.updateCarrito(pedido);


                      }
                    }
                  )
      c=c+1;
    }
  }

  updateCarrito(carrito: Pagado) {
  if (!carrito) return;
  this.servicio3.putCarrito(carrito)
              .subscribe(
                rt => console.log(rt),
                er => console.log(er),
                () => this.goLista()
              )
    }

  goLista() {
    console.log('ok');
    this.Borrar();
    let link = ['/home'];
    this.router.navigate(link);
  }

  Borrar (){

    this.servicio4.delCarrito()
              .subscribe(
                rs => console.log(rs),
                er => console.log(er),
                ()=> {
                  console.log('borrado')
                }
              )
}

}
