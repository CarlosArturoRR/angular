export class Totalcompra {
  constructor(

    public total: number
  ) { }
}
