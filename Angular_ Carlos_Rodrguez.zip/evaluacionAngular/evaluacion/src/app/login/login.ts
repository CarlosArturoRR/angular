export class Login {
  constructor(

    public email:string,
    public contrasena:string

  ) { }
}
