export class Contador {
  constructor(

    public contador: number
  ) { }
}
