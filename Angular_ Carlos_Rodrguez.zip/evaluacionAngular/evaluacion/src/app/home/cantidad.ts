export class Cantidad {
  constructor(
    public cantidad: number
  ) { }
}
