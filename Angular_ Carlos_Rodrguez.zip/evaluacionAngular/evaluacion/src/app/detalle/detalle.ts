export class Detalle {
  constructor(
    public nombre: string,
    public imagen: string,
    public precio: number,
    public disponibilidad: number
  ) { }
}
