import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Detalle } from './detalle';
import { DetalleService } from './detalle.service';

@Component({
  selector: 'app-detalle',
  templateUrl: './detalle.component.html',
  styleUrls: ['./detalle.component.css'],
  providers:[DetalleService]
})
export class DetalleComponent implements OnInit {


  lista: Detalle [];
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private servicio: DetalleService
  ) { }

  ngOnInit() {
    let id = this.route.snapshot.params['id'];
    if (!id) return;
    this.servicio.getProducto(id)
                 .subscribe(
                   rs => this.lista = rs,
                   er => console.log('Error: %s', er),
                   () => console.log(this.lista)

                 )
    console.log(id);
  }

  Regresar(){
    let link = ['/home'];
    this.router.navigate(link);
  }

}
