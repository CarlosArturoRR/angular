import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { CarritoComponent } from './carrito/carrito.component';
import { LoginComponent } from './login/login.component';
import { DetalleComponent } from './detalle/detalle.component';

const appRoutes: Routes = [

  { path: 'home', component: HomeComponent},
  { path: 'home/:id', component: HomeComponent},
  { path: 'carrito', component: CarritoComponent},
  { path: 'detalle/:id', component: DetalleComponent},
  { path: '', component: LoginComponent},


]

@NgModule ({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class AppRoutingModule { }
