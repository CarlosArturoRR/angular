var express = require('express');
var bodyparser = require('body-parser');
var app =  express();
var cors = require('cors');
/*var cors = require('./cors');*/
app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());

var connection = require('./connections');
var routes = require ('./routes');

/*app.use(cors.permisos);*/
app.use(cors());
connection.inicia();
routes.configurar(app);

var server = app.listen(8010, function(){
  console.log('Escuchando en el puerto ', server.address().port);
})
